<?php
/*
Template Name: Page without sidebar
*/
?>

<?php
	global $inove_nosidebar;
	$inove_nosidebar = true;
	include('page.php');
?>
